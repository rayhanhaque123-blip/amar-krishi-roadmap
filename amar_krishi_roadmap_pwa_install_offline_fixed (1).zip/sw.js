const CACHE_NAME = 'amar-krishi-roadmap-v3';
const APP_PREFIX = '/amar-krishi-roadmap/';
const CORE = [
  APP_PREFIX,
  APP_PREFIX + 'index.html',
  APP_PREFIX + 'manifest.webmanifest',
  APP_PREFIX + 'icon.svg',
  APP_PREFIX + 'icon-192.png',
  APP_PREFIX + 'icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // Cache essential files individually so one optional asset does not block installation.
    for (const url of CORE) {
      try {
        const response = await fetch(url, {cache: 'reload'});
        if (response.ok) await cache.put(url, response);
      } catch (e) {}
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter(key => key.startsWith('amar-krishi-roadmap-') && key !== CACHE_NAME)
      .map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;

    try {
      const response = await fetch(request);
      if (response && response.ok) {
        await cache.put(request, response.clone());
      }
      return response;
    } catch (error) {
      if (request.mode === 'navigate') {
        return (await cache.match(APP_PREFIX + 'index.html')) ||
               (await cache.match(APP_PREFIX)) ||
               new Response('অফলাইনে এই পৃষ্ঠাটি পাওয়া যাচ্ছে না। প্রথমে ইন্টারনেট দিয়ে অ্যাপটি খুলুন।', {
                 status: 503, headers: {'Content-Type': 'text/plain; charset=utf-8'}
               });
      }
      return new Response('', {status: 504, statusText: 'Offline'});
    }
  })());
});
